/* 
 * File:   CA_defines.h
 * Author: pablo
 *
 * Created on 13 de enero de 2014, 3:20
 */

#ifndef CA_DEFINES_H
#define	CA_DEFINES_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CA_DEFINES_H */

