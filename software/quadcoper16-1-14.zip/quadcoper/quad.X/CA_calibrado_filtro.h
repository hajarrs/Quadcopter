/* 
 * File:   calibrado_filtro.h
 * Author: pablo
 *
 * Created on 20 de diciembre de 2013, 0:25
 */

#ifndef CALIBRADO_FILTRO_H
#define	CALIBRADO_FILTRO_H

#include "CA_SetGetMPU6050.h"

#endif	/* CALIBRADO_FILTRO_H */

