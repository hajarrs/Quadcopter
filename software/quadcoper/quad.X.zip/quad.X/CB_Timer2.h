/* 
 * File:   CB_Timer2.h
 * Author: Raul
 *
 * Created on 28 de agosto de 2013, 11:40
 */

#ifndef CB_TIMER2_H
#define	CB_TIMER2_H

void Delay_Nop(unsigned int _contador);

#endif	/* CB_TIMER2_H */

