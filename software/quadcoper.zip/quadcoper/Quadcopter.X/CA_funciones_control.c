/* 
 * File:   CA_funciones_control.c
 * Author: pablo
 *
 * Created on 23 de enero de 2014, 23:41
 */
#include "CA_funciones_control.h"
int errorAnt = 0;

int _Pid_Posicion(int _setpoint, int _posicion_actual)
{
    int valorPID, _error;
    _error = _setpoint - _posicion_actual;
    valorPID = KP * (_error) + KD * (_error - errorAnt);

    errorAnt = _error;
    return (valorPID);
}

/*working variables*/
unsigned long lastTime;
double Input, Output, Setpoint;
double ITerm, lastInput;

// SetPoint = BIAS

int _PID(int _referencia, int _PosicionActual, int Tmuestreo, int _kp, int _ki, int _kd, int _Maximo, int _Minimo)
{

//    ITerm += (_ki * error);
//
//    if (ITerm > 2000) ITerm = 2000;
//    if (ITerm < -2000) ITerm = -2000;

    int Error = _referencia - _PosicionActual;
    int dError = (_PosicionActual - ( valorAuxAnterior));
    Output = _kp * Error - _kd * dError ;//+ ITerm;
   // if (Output >= _Maximo) Output = _Maximo;
   // if (Output <= _Minimo) Output = _Minimo;

    ( valorAuxAnterior) = _PosicionActual;

    PWM1 = /*BIAS1 +*/ Output;
    PWM4 = /*BIAS2 +*/  Output;

    //    enviar_valor_NOCR("valorAux = ",_referencia);
    //    enviar_valor_NOCR(" valorAuxAnterior = ",_PosicionActual);
        enviar_valor_NOCR("pid = ",Output);
    //    enviar_valor_NOCR(" Ep = ",error);
    //    enviar_valor_NOCR(" Ed = ",dInput);
    //    enviar_valor(" Ei = ",ITerm);



    return Output;
}

void getAngle_init()
{
    P[0][0] = 0; // Since we assume that the bias is 0 and we know the starting angle (use setAngle), the error covariance matrix is set like so - see: http://en.wikipedia.org/wiki/Kalman_filter#Example_application.2C_technical
    P[0][1] = 0;
    P[1][0] = 0;
    P[1][1] = 0;
}

double getAngle(double newAngle, double newRate, double dt)
{
    // KasBot V2 - Kalman filter module - http://www.x-firm.com/?page_id=145
    // Modified by Kristian Lauszus
    // See my blog post for more information: http://blog.tkjelectronics.dk/2012/09/a-practical-approach-to-kalman-filter-and-how-to-implement-it

    // Discrete Kalman filter time update equations - Time Update ("Predict")
    // Update xhat - Project the state ahead
    /* Step 1 */
    rate = newRate - bias;//lectura mas sesgo
    angle += dt * rate;//angulo  con el modelo (newton)
    // Update estimation error covariance - Project the error covariance ahead
    /* Step 2 */
    //operacion a*p*a(traspuesta)+q
    P[0][0] += dt * (dt * P[1][1] - P[0][1] - P[1][0] + Q_angle);
    P[0][1] -= dt * P[1][1];
    P[1][0] -= dt * P[1][1];
    P[1][1] += Q_bias * dt;

    // Discrete Kalman filter measurement update equations - Measurement Update ("Correct")
    // Calculate Kalman gain - Compute the Kalman gain
    /* Step 4 */

    S = P[0][0] + R_measure;//suma la varianza del ruido(aclculo intertermedio  para obtener L)

    /* Step 5 */
    //Kla funcion optimizada
    K[0] = P[0][0] / S;
    K[1] = P[1][0] / S;
    // Calculate angle and bias - Update estimate with measurement zk (newAngle)
    /* Step 3 */
    y = newAngle - angle;
    /* Step 6 */
    angle += K[0] * y;//y angulo medido //angle=estimado
    bias += K[1] * y;//

    // Calculate estimation error covariance - Update the error covariance
    /* Step 7 */
    P[0][0] -= K[0] * P[0][0];
    P[0][1] -= K[0] * P[0][1];
    P[1][0] -= K[1] * P[0][0];
    P[1][1] -= K[1] * P[0][1];

    return angle;
};


float Complementary2(float newAngle, float newRate, int looptime)
{

    float k = 10;
    float dtc2 = 0, x1 = 0, y1 = 0, x2 = 0;
    dtc2 = (float) (looptime) / 1000.0;
    x1 = (newAngle - x_angle2C) * k*k;
    y1 = dtc2 * x1 + y1;
    x2 = y1 + (newAngle - x_angle2C)*2 * k + newRate;
    x_angle2C = dtc2 * x2 + x_angle2C;
    return x_angle2C;
}

void get_calibrado_acelerometro(int milis, int n)
{
    DelayXmsT1(milis);
    int i;

    for (i = 0; i < n; i++)
    {
        calibra_ax = get_ax() + calibra_gx;
        calibra_ay = get_ay() + calibra_gy;
        calibra_az = get_az() + calibra_gz;
        calibra_gx = get_gx() + calibra_gx;
        calibra_gy = get_gy() + calibra_gy;
        calibra_gz = get_gz() + calibra_gz;
    }
    calibra_ax = calibra_ax / n;
    calibra_ay = calibra_ay / n;
    calibra_az = calibra_az / n;
    calibra_gx = calibra_gx / n;
    calibra_gy = calibra_gy / n;
    calibra_gz = calibra_gz / n;
}

void pid_dsp_configuracion() {
    fooPID.abcCoefficients = &abcCoefficient[0]; /*Set up pointer to derived coefficients */
    fooPID.controlHistory = &controlHistory[0]; /*Set up pointer to controller history samples */
    PIDInit(&fooPID); /*Clear the controler history and the controller output */
    kCoeffs[0] = Q15(0.9); // Kp   0.7
    kCoeffs[1] = Q15(0); // Ki 0.2
    kCoeffs[2] = Q15(0.00); // Kd   0.07
    PIDCoeffCalc(&kCoeffs[0], &fooPID); /*Derive the a,b, & c coefficients from the Kp, Ki & Kd */
}

int pid_dsp(int entrada) {

    fooPID.controlReference = Q15(_Q15ftoi(0)); /*Set the Reference Input for your controller */
    fooPID.measuredOutput = Q15(_Q15ftoi(entrada));
    PID(&fooPID);
    return (_itofQ15(fooPID.controlOutput));
}